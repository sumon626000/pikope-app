# Billiard Poker backend

Plain PHP 8.1+ and MySQL 8 (or MariaDB 10.5+). No framework, no Composer
packages - it runs on ordinary shared hosting.

It provides accounts, profiles, the leaderboard, rooms / matchmaking and
**server-authoritative online play for all four games**: the server shuffles
and deals, keeps hidden cards hidden, owns the turn and the shot clock, rules
every shot, awards penalties and decides the winner - and it **simulates every shot itself**, so a phone
can only say how it struck the cue ball, never what the balls did.

## Layout

```
public/index.php        front controller (document root)
public/uploads/         uploaded avatars (never executed)
src/Api.php             routes; auth, profile, leaderboard handlers
src/RoomService.php     create / quick match / join by code / leave
src/GameService.php     load-lock-apply-store, timeouts, rewards
src/Game/Physics.php       the table simulation (same maths as the app)
src/Game/PokerEngine.php   Billiard Poker rules
src/Game/PoolEngine.php    8-Ball, 9-Ball, 10-Ball rules
src/Ws/Server.php       WebSocket server for live play (bin/ws-server.php runs it)
src/Admin.php           /admin page (stats, players, matches, suspend)
src/Push.php            APK push (FCM) + in-app notification inbox
src/RateLimit.php, src/Mailer.php
bin/cleanup.php         cron housekeeping     bin/doctor.php   server self-check
bin/package.sh          builds the upload zip deploy/          DEPLOY.md, nginx / Apache examples
sql/schema.sql          tables
bin/migrate.php         applies the schema
tests/                  engine_test.php (no server), api_flow.php (against a server)
```

## Install

Step-by-step for cPanel shared hosting and for a VPS: **[deploy/DEPLOY.md](deploy/DEPLOY.md)**.
In short:

```bash
cp .env.example .env        # database, APP_URL, MAIL_FROM, ADMIN_USER / ADMIN_PASS
php bin/migrate.php         # creates the tables
php bin/doctor.php          # must end with "Ready."
```

**APK push:** set `FCM_SERVER_KEY` in `.env` (Firebase Cloud Messaging server key).
Configure events in **Admin → Push (APK)**. Replace `android/app/google-services.json`
and `lib/firebase_options.dart` with your real Firebase Android app (or run
`flutterfire configure`).

Point the web server's document root at `public/`, serve it over HTTPS, and
run `bin/cleanup.php` from cron every five minutes. Development:
`php -S 0.0.0.0:8080 -t public public/index.php`.

Then build the app with the API address:

```bash
flutter build apk --release --dart-define=API_BASE_URL=https://api.example.com
```

## API

All bodies are JSON. Authenticated calls send `Authorization: Bearer <token>`.
Errors are `{"error": "<code>", "message": "<text>"}` with a 4xx/5xx status.

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | liveness |
| GET | `/config` | `{ws}` - WebSocket address for live play, or null |
| POST | `/auth/guest` | `{displayName, avatar}` -> `{token, user}`; no sign-up needed to play |
| POST | `/auth/register` | `{phone, password}` BD mobile only; no OTP; guest token upgrades guest |
| POST | `/auth/login` | `{phone, password}` -> `{token, user}`; 5 failures / 15 min per number |
| POST | `/auth/logout` | revokes the token |
| POST | `/auth/forgot` | `{phone}` - SMS OTP for forgot password (admin → SMS OTP) |
| POST | `/auth/reset` | `{phone, code, password}` - after OTP, new password; old sessions signed out |
| GET / PATCH | `/me` | profile; PATCH `{displayName, avatar, tableSkin}` |
| POST | `/me/avatar` | multipart `file` (JPEG/PNG/WebP, <= 2 MB) |
| GET | `/leaderboard` | top 50 by wins, then coins |
| POST | `/matches/bot` | `{game, won}` - result of an offline match (small reward, rate limited) |
| POST | `/rooms` | `{game, private}` - new room, returns its 6-character code |
| POST | `/rooms/quick` | `{game}` - join a waiting public room or open one |
| POST | `/rooms/join` | `{code}` |
| GET | `/rooms/{id}` | poll; also the heartbeat that keeps the seat |
| POST | `/rooms/{id}/leave` | leave a waiting room, or forfeit a running match |
| POST | `/rooms/{id}/rematch` | after a match: a new private room for the same players |
| GET | `/games/{id}?since=<version>` | poll; `{unchanged: true}` if nothing is newer |
| POST | `/games/{id}/actions` | `{type, ...}` - see below; replies with the new state |
| GET | `/admin` | HTML page behind HTTP Basic (`ADMIN_USER` / `ADMIN_PASS`); off when unset |

`game` is `poker`, `eight`, `nine` or `ten`. A room starts its match as soon as
it is full (4 seats for poker, 2 otherwise).

### Actions

| type | fields | games |
|---|---|---|
| `pick_break` | `index` (0-29) | poker |
| `select_card` | `cardId` | poker |
| `select_free` | `ball` (14 or 15) | poker |
| `declare` | | poker |
| `call_pocket` | `pocket` (0-5) | 8-ball |
| `push_out` | | 9-ball (toggle) |
| `push_out_answer` | `shoot` (bool) | 9-ball |
| `shoot` | `dirX, dirY, power, spinX, spinY, cueX, cueY` | all |
| `leave` | | all |

A card id is `(rank - 1) * 4 + suit` with suit 0 clubs, 1 diamonds, 2 hearts,
3 spades (rank 1 = Ace ... 13 = King).

## Live play: WebSocket

`bin/ws-server.php` is a WebSocket server written in plain PHP (no extensions
or packages). The app learns its address from `GET /config` (`WS_PUBLIC_URL`),
signs in with the same bearer token, and from then on:

| App sends | Server answers |
|---|---|
| `{t:"auth", token}` | `{t:"auth_ok", userId}` |
| `{t:"join", gameId}` | `{t:"state", id, version, serverNow, state}` - and again on every change |
| `{t:"act", gameId, n, action}` | the new state to every player (`re: n` to the sender), or `{t:"error", code, message, re}` |
| `{t:"room", roomId}` | `{t:"room", room}` now and whenever the room changes |
| `{t:"ping"}` | `{t:"pong"}` |

`action` is exactly what `POST /games/{id}/actions` takes. The server also
watches each match's version in the database, so a change made over HTTP (or
by the cron job) is pushed to socket players too - the two transports can be
mixed in one match. The HTTP endpoints remain; the app uses them whenever the
socket is unavailable.

## How a shot works

1. The shooter's app sends `shoot`: the unit aim direction, power, spin and -
   with ball in hand - where the cue ball goes.
2. The server checks the turn and the target, places the cue ball, **runs the
   physics**, rules on the outcome, re-spots balls and stores where everything
   rests. The reply (and everyone's next poll) carries `lastShot`,
   `lastResult` and `balls`.
3. Every app animates the same stroke with the same physics, then shows the
   ruling and takes the ball positions from the server.

`src/Game/Physics.php` is a line-for-line port of the app's
`lib/game/physics/physics_world.dart`. The direction is sent as a vector, not
an angle, so both sides start from identical numbers, and nothing inside the
simulation uses trigonometry. The online tests compare the app's and the
server's resting positions after every shot; they differ by exactly 0.
**If you change the physics on one side, change the other.**

Shot clocks are enforced by the server: an overdue turn is ruled a timeout on
the next request from any player, or by the cron job if nobody is polling.
Three missed turns in a row forfeit.

## Trust model

Decided by the server and not forgeable by a client: cards and the deal, turn
order, where the balls go, fouls and penalties, the clock, the winner, coins.
A client chooses only its own aim, power, spin and (with ball in hand) the cue
ball position, which the server validates.

What is still trusted: results of **offline** matches against bots
(`/matches/bot`) - they pay little and are rate limited, but they do count as
wins on the leaderboard. Remove that endpoint's win counting if the leaderboard
must be online-only.

Sign-up, sign-in, password reset and the admin page are rate limited
(`rate_limits` table). Every shot is logged in `game_shots` for `SHOT_LOG_DAYS`.

## Tests

```bash
php tests/engine_test.php                       # rules with a controlled clock
# whole matches through the API; the server must run with APP_TEST_HOOKS=1,
# SMS_LOG=<file> in .env (or pass the same path as argv[2]) and an admin login (development only):
php tests/api_flow.php http://127.0.0.1:8080 <sms-log-file> <admin-user>:<admin-pass>
```

From the app project (real clients, real physics, against a running server):

```bash
API_BASE_URL=http://127.0.0.1:8080 flutter test test_online/online_match_test.dart
```
